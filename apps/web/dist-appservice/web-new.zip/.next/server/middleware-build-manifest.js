globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/1NvHuI8YODmxGYzpJTKBe/_buildManifest.js",
    "static/1NvHuI8YODmxGYzpJTKBe/_ssgManifest.js",
    "static/1NvHuI8YODmxGYzpJTKBe/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/3s6nzrbk-8mnv.js",
    "static/chunks/19mx3mg6lkumu.js",
    "static/chunks/3i6wn1nq2vjk_.js",
    "static/chunks/2-rtuqsgzmno4.js",
    "static/chunks/turbopack-00jh4i0686v1e.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
